// Central registry of wheel properties consumed across the entire chain:
//   - filtersSlice.js  : generates Redux filter state
//   - wheelsSelectors  : iterates for filtering/sorting
//   - FilterPanel      : renders filter and sort UI
//   - ComparisonTable  : renders table columns
//   - ColumnSelector   : controls column visibility
//
// To add a new wheel property (filter + sort + column), simply add an entry
// to WHEEL_PROPERTIES — no other files should need modification.

import { HookBadge } from '../components/MiniComparator/badges';

/**
 * @typedef {Object} WheelProperty
 * @property {string} id            Unique identifier (Redux key + column).
 * @property {string} label         Displayed label (filter + column + sort).
 * @property {string} group         'general' | 'rims' | 'subs'.
 * @property {(w: any) => any} accessor  Always a function (handles computed cases like min price).
 * @property {string} [unit]        Unit suffix used for default cell rendering.
 * @property {FilterSpec} [filter]  Absent => property not filterable.
 * @property {SortSpec[]} [sorts]   Absent => not sortable.
 * @property {ColumnSpec} [column]  Table display override.
 *
 * @typedef {{type: 'range', step?: number}
 *         | {type: 'multiSelect'}
 *         | {type: 'triState', labels: [string, string, string]}} FilterSpec
 *
 * @typedef {{id: string, label: string, direction: 'asc' | 'desc' | 'localeCompare', accessor?: (w:any)=>any}} SortSpec
 *
 * @typedef {{required?: boolean, headClassName?: string, cellClassName?: string,
 *           renderCell?: (w:any) => any, hidden?: boolean, defaultVisible?: boolean}} ColumnSpec
 */

// Exported helper because reused in multiple entries (price, price column).
export const minPrice = (wheel) => Math.min(...wheel.prices.map((p) => p.price_eur));

export const COLUMN_GROUPS = [
  { id: 'general', label: 'General specs' },
  { id: 'rims', label: 'Rims' },
  { id: 'subs', label: 'Subcomponents' },
];

/** @type {WheelProperty[]} */
export const WHEEL_PROPERTIES = [
  {
    id: 'image',
    label: 'Image',
    group: 'general',
    accessor: (w) => w.image,
    column: {
      headClassName: 'px-4 py-3 font-semibold',
      cellClassName: 'px-2 py-2',
      renderCell: (w) => (
        <img src={w.image} alt={w.model} className="w-16 h-16 object-contain rounded" />
      ),
    },
  },

  {
    id: 'model',
    label: 'Model',
    group: 'general',
    accessor: (w) => w.model,
    sorts: [
      { id: 'name', label: 'Name (A → Z)', direction: 'localeCompare' },
    ],
    column: {
      required: true,
      headClassName: 'px-4 py-3 font-semibold',
      cellClassName: 'px-4 py-3 font-medium text-ink-900',
      renderCell: (w) => (
        <>
          <span className="text-ink-500 font-normal text-xs">{w.brand}</span>
          <br />
          {w.model}
        </>
      ),
    },
  },

  {
    id: 'brand',
    label: 'Brand',
    group: 'general',
    accessor: (w) => w.brand,
    filter: { type: 'multiSelect' },
    // Filterable but no dedicated column — brand is already visible in Model column.
    column: { hidden: true },
  },

  {
    id: 'weight',
    label: 'Weight',
    group: 'general',
    unit: ' g',
    accessor: (w) => w.weight_grams,
    filter: { type: 'range', step: 10 },
    sorts: [
      { id: 'weight_asc', label: 'Weight (light → heavy)', direction: 'asc' },
      { id: 'weight_desc', label: 'Weight (heavy → light)', direction: 'desc' },
    ],
    column: {
      headClassName: 'px-4 py-3 font-semibold text-right',
      cellClassName: 'px-4 py-3 text-ink-700 text-right tabular-nums',
    },
  },

  {
    id: 'price',
    label: 'Price',
    group: 'general',
    unit: ' €',
    // Computed accessor: value is not in a direct field.
    accessor: minPrice,
    filter: { type: 'range', step: 50 },
    sorts: [
      { id: 'price_asc', label: 'Price (low → high)', direction: 'asc' },
      { id: 'price_desc', label: 'Price (high → low)', direction: 'desc' },
    ],
    column: {
      headClassName: 'px-4 py-3 font-semibold text-right',
      cellClassName: 'px-4 py-3 text-right font-semibold text-ink-900 tabular-nums',
      renderCell: (w) => `${minPrice(w).toLocaleString('fr-FR')} €`,
    },
  },

  {
    id: 'diameter',
    label: 'Diameter',
    group: 'general',
    unit: ' mm',
    accessor: (w) => w.diameter_mm,
    filter: { type: 'multiSelect' },
    column: {
      defaultVisible: false,
      headClassName: 'px-4 py-3 font-semibold text-right',
      cellClassName: 'px-4 py-3 text-ink-700 text-right tabular-nums',
    },
  },

  {
    id: 'rimMaterial',
    label: 'Rim material',
    group: 'rims',
    accessor: (w) => w.rim.material,
    filter: { type: 'multiSelect' },
    column: {
      headClassName: 'px-4 py-3 font-semibold',
      cellClassName: 'px-4 py-3 text-ink-700',
    },
  },

  {
    id: 'hookless',
    label: 'Hookless',
    group: 'rims',
    accessor: (w) => w.rim.hookless,
    filter: { type: 'triState', labels: ['All', 'Hookless', 'Hooked'] },
    column: {
      headClassName: 'px-4 py-3 font-semibold',
      cellClassName: 'px-4 py-3',
      // Display a badge instead of raw boolean.
      renderCell: (w) => <HookBadge hookless={w.rim.hookless} />,
    },
  },

  {
    id: 'depth',
    label: 'Depth',
    group: 'rims',
    unit: ' mm',
    accessor: (w) => w.rim.depth_mm,
    filter: { type: 'range' },
    sorts: [
      { id: 'depth_asc', label: 'Depth (shallow → deep)', direction: 'asc' },
      { id: 'depth_desc', label: 'Depth (deep → shallow)', direction: 'desc' },
    ],
    column: {
      headClassName: 'px-4 py-3 font-semibold text-right',
      cellClassName: 'px-4 py-3 text-ink-700 text-right tabular-nums',
    },
  },

  {
    id: 'rimWidth',
    label: 'Rim width',
    group: 'rims',
    unit: ' mm',
    accessor: (w) => w.rim.externalWidth_mm,
    filter: { type: 'range' },
    sorts: [
      { id: 'rimWidth_asc', label: 'Rim width (narrow → wide)', direction: 'asc' },
      { id: 'rimWidth_desc', label: 'Rim width (wide → narrow)', direction: 'desc' },
    ],
    column: {
      defaultVisible: false,
      headClassName: 'px-4 py-3 font-semibold text-right',
      cellClassName: 'px-4 py-3 text-ink-700 text-right tabular-nums',
    },
  },

  {
    id: 'hub',
    label: 'Hub',
    group: 'subs',
    accessor: (w) => `${w.hub.brand} ${w.hub.model}`,
    column: {
      headClassName: 'px-4 py-3 font-semibold',
      cellClassName: 'px-4 py-3 font-medium text-ink-900',
      renderCell: (w) => (
        <>
          <span className="text-ink-500 font-normal text-xs">{w.hub.brand}</span>
          <br />
          {w.hub.model}
        </>
      ),
    },
  },

  {
    id: 'hubBrand',
    label: 'Hub brand',
    group: 'subs',
    accessor: (w) => w.hub.brand,
    filter: { type: 'multiSelect' },
    column: { hidden: true },
  },

  {
    id: 'hubModel',
    label: 'Hub model',
    group: 'subs',
    accessor: (w) => w.hub.model,
    filter: { type: 'multiSelect' },
    column: { hidden: true },
  },

  {
    id: 'spokes',
    label: 'Spokes',
    group: 'subs',
    accessor: (w) => `${w.spokes.brand} ${w.spokes.model}`,
    column: {
      defaultVisible: false,
      headClassName: 'px-4 py-3 font-semibold',
      cellClassName: 'px-4 py-3 font-medium text-ink-900',
      renderCell: (w) => (
        <>
          <span className="text-ink-500 font-normal text-xs">{w.spokes.brand}</span>
          <br />
          {w.spokes.model}
        </>
      ),
    },
  },

  {
    id: 'spokesBrand',
    label: 'Spokes brand',
    group: 'subs',
    accessor: (w) => w.spokes.brand,
    filter: { type: 'multiSelect' },
    column: { hidden: true },
  },

  {
    id: 'spokesModel',
    label: 'Spokes model',
    group: 'subs',
    accessor: (w) => w.spokes.model,
    filter: { type: 'multiSelect' },
    column: { hidden: true },
  },

  {
    id: 'spokeMaterial',
    label: 'Spoke material',
    group: 'subs',
    accessor: (w) => w.spokes.material,
    filter: { type: 'multiSelect' },
    column: {
      defaultVisible: false,
      headClassName: 'px-4 py-3 font-semibold',
      cellClassName: 'px-4 py-3 text-ink-700',
    },
  },
];

// --- Registry reading helpers ---

/** List of filterable properties (i.e. with filter defined). */
export const getFilterableProperties = () =>
  WHEEL_PROPERTIES.filter((p) => p.filter);

/** List of properties displayable as table columns. */
export const getColumnProperties = () =>
  WHEEL_PROPERTIES.filter((p) => !p.column?.hidden);

/**
 * Flat list of all sort options declared in the registry.
 * Each entry carries its property accessor (unless overridden by SortSpec.accessor).
 */
export const getAllSorts = () =>
  WHEEL_PROPERTIES.flatMap((p) =>
    (p.sorts ?? []).map((s) => ({
      ...s,
      propertyId: p.id,
      accessor: s.accessor ?? p.accessor,
    }))
  );

/** Default sort identifier (first declared in registry). */
export const getDefaultSortId = () => getAllSorts()[0]?.id ?? null;

/** Property lookup by id (useful for dynamic options). */
export const getPropertyById = (id) =>
  WHEEL_PROPERTIES.find((p) => p.id === id);
